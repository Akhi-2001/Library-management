<html>
	<head>
		<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,700">
		<link rel="stylesheet" type="text/css" href="css/header_style.css" />
	</head>
	<body>
		<header>
			<a href="./">
				<div id="cd-logo">
					<img src="img/ic_logo2.svg" alt="Logo" width="45" height="45" />
					<p>Library Management System</p>
				</div>
			</a>
		</header>
	</body>
</html>